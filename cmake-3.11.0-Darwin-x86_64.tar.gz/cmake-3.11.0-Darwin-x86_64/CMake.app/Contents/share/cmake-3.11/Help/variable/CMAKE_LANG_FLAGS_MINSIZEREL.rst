CMAKE_<LANG>_FLAGS_MINSIZEREL
-----------------------------

This variable is the ``MinSizeRel`` variant of the
:variable:`CMAKE_<LANG>_FLAGS_<CONFIG>` variable.
