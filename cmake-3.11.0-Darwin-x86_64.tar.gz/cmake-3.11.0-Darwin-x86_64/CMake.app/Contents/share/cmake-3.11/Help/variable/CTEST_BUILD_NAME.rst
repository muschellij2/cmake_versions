CTEST_BUILD_NAME
----------------

Specify the CTest ``BuildName`` setting
in a :manual:`ctest(1)` dashboard client script.
