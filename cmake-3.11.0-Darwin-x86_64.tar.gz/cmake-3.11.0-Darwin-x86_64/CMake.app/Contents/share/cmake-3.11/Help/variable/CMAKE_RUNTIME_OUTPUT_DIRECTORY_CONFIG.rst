CMAKE_RUNTIME_OUTPUT_DIRECTORY_<CONFIG>
---------------------------------------

Where to put all the :ref:`RUNTIME <Runtime Output Artifacts>`
target files when built for a specific configuration.

This variable is used to initialize the
:prop_tgt:`RUNTIME_OUTPUT_DIRECTORY_<CONFIG>` property on all the targets.
See that target property for additional information.
