CTEST_CHECKOUT_COMMAND
----------------------

Tell the :command:`ctest_start` command how to checkout or initialize
the source directory in a :manual:`ctest(1)` dashboard client script.
