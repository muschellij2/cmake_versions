CMAKE_<LANG>_CLANG_TIDY
-----------------------

Default value for :prop_tgt:`<LANG>_CLANG_TIDY` target property.
This variable is used to initialize the property on each target as it is
created.  This is done only when ``<LANG>`` is ``C`` or ``CXX``.
