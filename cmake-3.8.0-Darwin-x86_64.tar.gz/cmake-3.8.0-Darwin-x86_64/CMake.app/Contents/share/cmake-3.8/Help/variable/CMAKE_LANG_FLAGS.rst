CMAKE_<LANG>_FLAGS
------------------

Flags for all build types.

``<LANG>`` flags used regardless of the value of :variable:`CMAKE_BUILD_TYPE`.
