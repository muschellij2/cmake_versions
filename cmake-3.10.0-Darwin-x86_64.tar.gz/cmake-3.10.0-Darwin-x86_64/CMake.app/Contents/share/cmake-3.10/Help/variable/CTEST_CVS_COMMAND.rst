CTEST_CVS_COMMAND
-----------------

Specify the CTest ``CVSCommand`` setting
in a :manual:`ctest(1)` dashboard client script.
