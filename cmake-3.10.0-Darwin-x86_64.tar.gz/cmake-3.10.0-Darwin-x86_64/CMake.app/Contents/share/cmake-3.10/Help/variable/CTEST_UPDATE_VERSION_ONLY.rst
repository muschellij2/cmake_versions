CTEST_UPDATE_VERSION_ONLY
-------------------------

Specify the CTest ``UpdateVersionOnly`` setting
in a :manual:`ctest(1)` dashboard client script.
