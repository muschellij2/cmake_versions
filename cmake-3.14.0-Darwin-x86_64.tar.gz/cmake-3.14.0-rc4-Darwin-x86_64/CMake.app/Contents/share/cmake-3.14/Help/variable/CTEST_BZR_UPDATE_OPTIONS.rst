CTEST_BZR_UPDATE_OPTIONS
------------------------

Specify the CTest ``BZRUpdateOptions`` setting
in a :manual:`ctest(1)` dashboard client script.
