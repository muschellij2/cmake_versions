CMAKE_<LANG>_COMPILER_PREDEFINES_COMMAND
----------------------------------------

Command that outputs the compiler pre definitions.

See :prop_tgt:`AUTOMOC` which uses
:variable:`CMAKE_CXX_COMPILER_PREDEFINES_COMMAND <CMAKE_<LANG>_COMPILER_PREDEFINES_COMMAND>`
to generate the :prop_tgt:`AUTOMOC_COMPILER_PREDEFINES`.
