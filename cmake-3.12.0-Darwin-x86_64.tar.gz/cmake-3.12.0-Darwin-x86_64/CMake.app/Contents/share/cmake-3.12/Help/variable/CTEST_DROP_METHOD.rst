CTEST_DROP_METHOD
-----------------

Specify the CTest ``DropMethod`` setting
in a :manual:`ctest(1)` dashboard client script.
