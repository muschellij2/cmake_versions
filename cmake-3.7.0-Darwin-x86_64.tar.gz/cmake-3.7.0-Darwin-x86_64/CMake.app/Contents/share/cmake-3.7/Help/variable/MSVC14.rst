MSVC14
------

``True`` when using the Microsoft Visual Studio ``v140`` toolset
(``cl`` version 19) or another compiler that simulates it.
